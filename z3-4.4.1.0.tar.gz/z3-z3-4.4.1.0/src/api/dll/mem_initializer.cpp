// Automatically generated file.
#include"gparams.h"
#include"debug.h"
#include"symbol.h"
#include"rational.h"
#include"trace.h"
#include"prime_generator.h"
void mem_initialize() {
initialize_symbols();
rational::initialize();
gparams::init();
}
void mem_finalize() {
gparams::finalize();
finalize_debug();
finalize_symbols();
rational::finalize();
finalize_trace();
prime_iterator::finalize();
}
